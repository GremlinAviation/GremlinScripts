is_left = true
dofile(LockOn_Options.common_script_path.."KNEEBOARD/declare_kneeboard_device.lua")