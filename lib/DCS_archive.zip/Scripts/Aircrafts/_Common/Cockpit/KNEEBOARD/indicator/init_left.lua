is_left = true
dofile(LockOn_Options.common_script_path.."KNEEBOARD/indicator/init.lua")

