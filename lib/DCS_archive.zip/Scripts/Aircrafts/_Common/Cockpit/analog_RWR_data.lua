dofile('Scripts/Aircrafts/_Common/Cockpit/wsTypes_SAM.lua')
dofile('Scripts/Aircrafts/_Common/Cockpit/wsTypes_Airplane.lua')
dofile('Scripts/Aircrafts/_Common/Cockpit/wsTypes_Ship.lua')
dofile('Scripts/Aircrafts/_Common/Cockpit/wsTypes_Missile.lua')

DefaultType          = 100
DEFAULT_TYPE_ = {DefaultType, DefaultType, DefaultType, DefaultType}

wstype_emission_data = {
    {
        E_2C_,       --AN/APS-145
        params = {
            freq = {4e8,4.5e8},                     -- frequency range, Hz - note, SPO-10 won't see this radar so the rest of data is filled in just for completeness
            prf = {300,300},                        -- pulse repetition frequency range, Hz - this is out of range of SPO-10
            --MDS = 10^(-110/10),                   -- minimum discernible signal, W, default is -110 dBm
            P_max = 1e6,                            -- peak power, W, can be used instead of MDS together with R_max
            R_max = 6.5e5,                          -- maximum detection range against a 100m^2 RCS target, can be used instead of MDS together with P_max
            G = 10.^(20./10.),                      -- antenna gain (20dBi - array of yagi antennas), non-dim
            hpbw = math.rad(7),                     -- half power beamwidth, rad
            scan_rate = 0.523,                      -- antenna sweep rate, rad/s
            -- scan_period = 12                     -- full scan cycle period. For 2d radars/ 1-bar pattern leave this out or set to 0
            side_lobe_attenuation = 10.^(-15./10.), -- first sidelobe level
            side_lobe_level = 10.^(-40./10.)        -- average side lobe level
        }
    },
    {
        Gepard,
        params = {
            freq = {2e9,3e9},
            prf = {300,1000},
            MDS = 0.001*10.^(-105./10.),
            G = 10.^(25./10.),
            hpbw = math.rad(10),
            scan_rate = 6.28,
            side_lobe_attenuation = 10.^(-15./10.),
            side_lobe_level = 10.^(-40./10.),

        }
    },
    {
        Tunguska_2S6,
        params = {
            freq = {2e9, 3e9},
            prf = {100,6000},
            MDS = 0.001*10.^(-105./10),
            G = 10.^(25./10.),
            hpbw = math.rad(5),
            scan_rate = 6.28,
            side_lobe_attenuation = 10.^(-15./10.),
            side_lobe_level = 10.^(-40./10.),

        }
    },
    {
        Osa_9A33,
        params = {
            freq = { 6e9,8e9 },
            G = 10.^(25. / 10.),
            MDS = 0.001 * 10.^(-107. / 10.),
            hpbw = math.rad(5),
            prf = { 100,6000 },
            scan_rate = 6.28,
            side_lobe_attenuation = 10.^(-20. / 10.),
            side_lobe_level = 10.^ (-50. / 10.)
        }
    },
    {
        ALBATROS_,
        params = {  --Osa
            freq = { 6.0e9,8.0e9 },
            G = 10.^(25. / 10.),
            MDS = 0.001 * 10.^(-107. / 10.),
            hpbw = math.rad(5),
            prf = { 100,6000 },
            scan_rate = 6.28,
            side_lobe_attenuation = 10.^(-20. / 10.),
            side_lobe_level = 10.^ (-50. / 10.)
        }
    },
    {
        REZKY_,
        params = {  --Osa
            freq = { 6.0e9,8.0e9 },
            G = 10.^(25. / 10.),
            MDS = 0.001 * 10.^(-107. / 10.),
            hpbw = math.rad(5),
            prf = { 100,6000 },
            scan_rate = 6.28,
            side_lobe_attenuation = 10.^(-20. / 10.),
            side_lobe_level = 10.^ (-50. / 10.)
        }
    },
    {
        Tor_9A331,
        params = 
        {
            freq = {4.0e9, 8.0e9},
            prf = { 100,6000 },
            G = 10.^(30./10.),
            MDS = 0.001* 10.^(-116/10.),
            hpbw = math.rad(1.5),
            scan_rate = 0.558,
            side_lobe_attenuation = 10.^(-20. / 10.),
            side_lobe_level = 10.^ (-50. / 10.)
        }
    },
    {
        Kuznecow_,
        params =    --Kinzhal
        {
            freq = {4.0e9, 8.0e9},
            G = 10.^(30./10.),
            prf = { 100,6000 },
            MDS = 0.001* 10.^(-116/10.),
            hpbw = math.rad(1.5),
            scan_rate = 0.558,
            side_lobe_attenuation = 10.^(-20. / 10.),
            side_lobe_level = 10.^ (-50. / 10.)
        }
    },
    {
        NEUSTRASH_,
        params =    --Kinzhal
        {
            freq = {4.0e9, 8.0e9},
            G = 10.^(30./10.),
            prf = { 100,6000 },
            MDS = 0.001* 10.^(-116/10.),
            hpbw = math.rad(1.5),
            scan_rate = 0.558,
            side_lobe_attenuation = 10.^(-20. / 10.),
            side_lobe_level = 10.^ (-50. / 10.)
        }
    }
}

string_emission_data = {
    ["F-5E-3"] = { --AN/APQ-159
        freq = {8e9,12e9},        
        prf = {1000,1000},        
        MDS = 0.001*10^(-105/10), 
        G = 10.^(28./10.),        
        hpbw = math.rad(4),       
        scan_rate = 2.5,              
        -- scan_period = 12         --1 bar           
        side_lobe_attenuation = 10.^(-20./10.),
        side_lobe_level = 10.^(-40./10.)       
    },
    ["CV_1143_5"] = {  --Kinzhal
        freq = {4.0e9, 8.0e9},
        G = 10.^(30./10.),
        prf = { 100,6000 },
        MDS = 0.001* 10.^(-116/10.),
        hpbw = math.rad(1.5),
        scan_rate = 6.28,
        side_lobe_attenuation = 10.^(-20. / 10.),
        side_lobe_level = 10.^ (-50. / 10.)
    }
}