-- debug scope window 
indicators = {
 {"ccChart",LockOn_Options.common_script_path.."dbg_chart.lua"  ,nil,{{}, {sw = LockOn_Options.screen.aspect - 0.01,sh = 0.5 - 0.01}}},
}
