--- Names of Missiles for cockpit use

dofile("Scripts/Database/wsTypes.lua")

MICA_R_		=	{wsType_Weapon, wsType_Missile, wsType_AA_Missile, MICA_R}
P_27AE_		=	{wsType_Weapon, wsType_Missile, wsType_AA_Missile, P_27AE}
P_77_		=	{wsType_Weapon, wsType_Missile, wsType_AA_Missile, P_77}
P_37_		=	{wsType_Weapon, wsType_Missile, wsType_AA_Missile, P_37}
AIM_54_		=	{wsType_Weapon, wsType_Missile, wsType_AA_Missile, AIM_54}
AIM_120_	=	{wsType_Weapon, wsType_Missile, wsType_AA_Missile, AIM_120}
AIM_120C_	=	{wsType_Weapon, wsType_Missile, wsType_AA_Missile, AIM_120C}

----------------------------------------------------------------------------------------



















