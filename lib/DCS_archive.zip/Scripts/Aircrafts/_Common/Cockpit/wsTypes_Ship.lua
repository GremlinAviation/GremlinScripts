--- Names of Ships for cockpit use

dofile("Scripts/Database/wsTypes.lua")

Kuznecow_	= 	{wsType_Navy, wsType_Ship, wsType_AirCarrier, Kuznecow}
VINSON_		=	{wsType_Navy, wsType_Ship, wsType_AirCarrier, VINSON}
MOSCOW_		=	{wsType_Navy, wsType_Ship, wsType_HCarrier,   MOSCOW}
GROZNY_		=	{wsType_Navy, wsType_Ship, wsType_HCarrier,   GROZNY}
AZOV_		=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, AZOV}
ALBATROS_	=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, ALBATROS}
AMETYST_	=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, AMETYST}
OREL_		=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, OREL}
REZKY_		=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, REZKY}
PERRY_		=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, PERRY}
OSA_		=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, OSA}
MOLNIYA_	=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, MOLNIYA}
SKORY_		=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, SKORY}
SPRUANCE_	=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, SPRUANCE}
TICONDEROGA_=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, TICONDEROGA}
BORA_		=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, BORA}
BOBRUISK_	=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, BOBRUISK}
VETER_		=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, VETER}
NEUSTRASH_	=	{wsType_Navy, wsType_Ship, wsType_ArmedShip, NEUSTRASH}

----------------------------------------------------------------------------------------



















