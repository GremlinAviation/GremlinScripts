
-- HelicopterTrimmerZonePitch = 0.05

-- reserved