troops = {
    troop('Abkhazia Military Forces', _('Abkhazia Military Forces'), 'MilitaryForces.png'),
};
