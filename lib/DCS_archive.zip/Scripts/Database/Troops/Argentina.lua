troops = {
--ARGENTINE AIR FORCE
    troop('Section Break', _('*ARGENTINE AIR FORCE*'), 'Argentine_Air_Force.png'),
	troop('AA - 1 Escuadrilla Aeronaval De Caza Y Ataque', _('AA - 1 Escuadrilla Aeronaval De Caza Y Ataque'), '1 Escuadrilla Aeronaval De Caza Y Ataque.png'),
    troop('AA - 2 Escuadrilla Aeronaval de Caza y Ataque', _('AA - 2 Escuadrilla Aeronaval de Caza y Ataque'), '2 Escuadrilla Aeronaval de Caza y Ataque.png'),
    troop('AA - 3 Escuadrilla Aeronaval De Caza Y Ataque', _('AA - 3 Escuadrilla Aeronaval De Caza Y Ataque'), '3 Escuadrilla Aeronaval De Caza Y Ataque.png'),
	troop('AA - Grupo 4 De Caza Bombardero', _('AA - Grupo 4 De Caza Bombardero'), 'Grupo 4 De Caza Bombardero.png'),
	troop('FAA - IV Brigada Aerea', _('FAA - IV Brigada Aerea'), 'FAA - IV Brigada Aerea.png'),
	troop('FAA - V Brigada Aerea - A-4AR Fightinghawk', _('FAA - V Brigada Aerea - A-4AR Fightinghawk'), 'FAA - V Brigada Aerea - A-4AR Fightinghawk.png'),
    troop('FAA - V Brigada Aerea - Grupo 4 de Caza', _('FAA - V Brigada Aerea - Grupo 4 de Caza'), 'FAA - V Brigada Aerea - Grupo 4 de Caza.png'),
    troop('FAA - V Brigada Aerea - Grupo 5 de Caza', _('FAA - V Brigada Aerea - Grupo 5 de Caza'), 'FAA - V Brigada Aerea - Grupo 5 de Caza.png'),
    troop('FAA - VI Brigada Aerea - Grupo 6 de Caza', _('FAA - VI Brigada Aerea - Grupo 6 de Caza'), 'FAA - VI Brigada Aerea - Grupo 6 de Caza.png'),
    troop('EA - VII Brigada Aerea Grupo Artillero', _('EA - VII Brigada Aerea Grupo Artillero'), 'VII Brigada Aerea Grupo Artillero.png'),
    troop('EA - VIII Brigada Aerea', _('EA - VIII Brigada Aerea'), 'VIII Brigada Aerea.png'),
    troop('EA - IX Brigada Aerea - Escuadron IV de Ataque - IA-58 Pucara', _('EA - IX Brigada Aerea - Escuadron IV de Ataque - IA-58 Pucara'), 'FAA - IX Brigada Aerea - Escuadron IV de Ataque - IA-58 Pucara.png')
};
