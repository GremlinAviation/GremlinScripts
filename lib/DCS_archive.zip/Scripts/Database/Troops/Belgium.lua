troops = {
    troop('1 SM', _('1 SM'), '1sm.png'),
    troop('31 SM', _('31 SM'), '31sm.png'),
    troop('349 SM', _('349 SM'), '349sm.png'),
    troop('350 SM', _('350 SM'), '350sm.png'),
    troop('A-109 BA Hirundo', _('A-109 BA Hirundo'), 'A-109_BA_Hirundo_Military_Helicopter.png'),
    troop('Light Aviation Helicopter', _('Light Aviation Helicopter'), 'Light_Aviation_Helicopter.png'),
    troop('RSD 4 MAINTENA C BASIS KOKSIJDE', _('RSD 4 MAINTENA C BASIS KOKSIJDE'), 'RSD_4_MAINTENA_C_BASIS_KOKSIJDE.png'),
    troop('OCU', _('OCU'), 'OCU.png'),
};
