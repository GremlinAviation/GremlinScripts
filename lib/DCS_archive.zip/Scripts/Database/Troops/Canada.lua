troops = {
    troop('410 SQN COUGARS', _('410 SQN COUGARS'), '410sqn-Cougars.png'),
    troop('425 SQN ALOUETTE', _('425 SQN ALOUETTE'), '425sqn-Alouette.png'),
    troop('433 SQN PORCUPINE', _('433 SQN PORCUPINE'), '433sqn-Porcupine.png'),
    troop('439 SQN SABRETOOTH', _('433 SQN SABRETOOTH'), '439sqn-Sabretooth.png'),
    troop('441 SQN SYLVERFOX', _('433 SQN SYLVERFOX'), '441sqn-SylverFox.png'),
    troop('406 Helicopter Squadron', _('406 Helicopter Squadron'), '406_Helicopter_Squadron.png'),
    troop('427 Tactical Helicopter Squadron', _('427 Tactical Helicopter Squadron'), '427_Tactical_Helicopter_Squadron.png'),
    troop('430 Tactical Helicopter Squadron', _('430 Tactical Helicopter Squadron'), '430_Tactical_Helicopter_Squadron.png'),
    troop('438 Tactical Helicopter Squadron', _('438 Tactical Helicopter Squadron'), '438_Tactical_Helicopter_Squadron.png'),
};
