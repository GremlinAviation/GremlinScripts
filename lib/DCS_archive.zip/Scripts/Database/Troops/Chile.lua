troops = {
    troop('Grupo de Aviacion N.1', _('Grupo de Aviacion N.1'), '1.png'),
    troop('Grupo de Aviacion N.3', _('Grupo de Aviacion N.3'), '3.png'),
    troop('Grupo de Aviacion N.4', _('Grupo de Aviacion N.4'), '4.png'),
    troop('Grupo de Aviacion N.5', _('Grupo de Aviacion N.5'), '5.png'),
    troop('Grupo de Aviacion N.6', _('Grupo de Aviacion N.6'), '6.png'),
    troop('Grupo de Aviacion N.7', _('Grupo de Aviacion N.7'), '7.png'),
    troop('Grupo de Aviacion N.8', _('Grupo de Aviacion N.8'), '8.png'),
    troop('Grupo de Aviacion N.9', _('Grupo de Aviacion N.9'), '9.png'),
    troop('Grupo de Aviacion N.10', _('Grupo de Aviacion N.10'), '10.png'),
    troop('Grupo de Aviacion N.12', _('Grupo de Aviacion N.12'), '12.png'),
};
