troops = {
    troop('Skrydstrup Fighter Wing', _('Skrydstrup Fighter Wing'), 'Skrydstrup Fighter Wing.png'),
    troop('727 CRAVEN', _('727 CRAVEN'), '727.png'),
    troop('730 BIRDSONG', _('730 BIRDSONG'), '730 Fighter Squadron BIRDSONG.png'),
};
