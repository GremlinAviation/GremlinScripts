troops = {
    troop("COTE D'ARGENT", _("COTE D'ARGENT"), "Cote_d'Argent.png"),
    troop('SPA 162 TIGRE', _('SPA 162 TIGRE'), 'SPA-162-Tigre.png'),
    troop('SPA 166 AIGLE NOIR SUR DISQUE JAUNE', _('SPA 166 AIGLE NOIR SUR DISQUE JAUNE'), 'SPA-166-Aigle_noir_sur_disque_jaune.png'),
    troop("1-RHC EHM1 DRAGON", _("1-RHC EHM1 DRAGON"), "1-RHC_EHM1_DRAGON.png"),
    troop("HELICOPTER 5-RHC EHM2 COUGAR", _("HELICOPTER 5-RHC EHM2 COUGAR"), "HELICOPTER_5-RHC_EHM2_COUGAR.png"),
    troop("Valmy Helicopter Squadron", _("Valmy Helicopter Squadron"), "Valmy_Helicopter_Squadron.png"),
};
