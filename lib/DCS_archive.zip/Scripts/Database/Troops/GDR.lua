troops = {
--GDR AIR FORCE
    troop('Section Break', _('*GDR Air Force*'), 'GDR_Air_Force.png'),
    troop('JG1 Fritz Schmenkel', _('JG1 Fritz Schmenkel'), 'JG1_Fritz_Schmenkel.png'),
	troop('JG2 Juri Gagarin', _('JG2 Juri Gagarin'), 'JG2_Juri_Gagarin.png'),
	troop('JG3 Wladimir Komarow', _('JG3 Wladimir Komarow'), 'JG3_Wladimir_Komarow.png'),
	troop('JG7 Wilhelm Pieck', _('JG7 Wilhelm Pieck'), 'JG7_Wilhelm_Pieck.png'),
	troop('JG8 Hermann Matern', _('JG8 Hermann Matern'), 'JG8_Hermann_Matern.png'),
	troop('JG9 Heinrich Rau', _('JG9 Heinrich Rau'), 'JG9_Heinrich_Rau.png'),
	troop('JBG37 Klement Gottwald', _('JBG37 Klement Gottwald'), 'JBG37_Klement_Gottwald.png'),
	troop('JBG77 Gebhard Leberecht von Blucher', _('JBG77 Gebhard Leberecht von Blucher'), 'JBG77_Gebhard_Leberecht_von_Blucher.png'),
	troop('MFG28 Paul Wieczorek', _('MFG28 Paul Wieczorek'), 'MFG28_Paul_Wieczorek.png'),
};
