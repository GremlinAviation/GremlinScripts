troops = {
    troop('TAM', _('TAM'), 'TAM.png'),
};
