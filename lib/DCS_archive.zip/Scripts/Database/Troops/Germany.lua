troops = {
--GERMANY AIR FORCE
    troop('Section Break', _('*Bundeswehr Luftwaffe*'), 'Bundeswehr_Luftwaffe.png'),
	troop('FlBschBMVg', _('FlBschBMVg'), 'FlBschBMVg.png'),
    troop('FlgAusbZLw', _('FlgAusbZLw'), 'FlgAusbZLw.png'),
    troop('HSG 64', _('HSG 64'), 'HSG_64.png'),
    troop('LTG 61', _('LTG 61'), 'LTG_61.png'),
    troop('LTG 62', _('LTG 62'), 'LTG_62.png'),
	troop('LTG 63', _('LTG 63'), 'LTG_63.png'),
	troop('TaktLwG 31', _('TaktLwG 31'), 'TaktLwG_31.png'),
    troop('TaktLwG 33', _('TaktLwG 33'), 'TaktLwG_33.png'),
    troop('TaktLwG 51', _('TaktLwG 51'), 'TaktLwG_51.png'),
	troop('TaktLwG 71', _('TaktLwG 71'), 'TaktLwG_71.png'),
	troop('TaktLwG 73', _('TaktLwG 73'), 'TaktLwG_73.png'),
    troop('TaktLwG 74', _('TaktLwG 74'), 'TaktLwG_74.png'),
};
