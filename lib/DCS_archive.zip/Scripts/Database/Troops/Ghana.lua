troops = {
    troop('GhanaAF', _('Ghana Air Force'), 'ghana-air-force.png'),
};
