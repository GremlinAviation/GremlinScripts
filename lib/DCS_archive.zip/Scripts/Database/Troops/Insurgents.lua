troops = {
    troop('Warriors of saber & star', _('Warriors of saber & star'), 'insurgents.png'),
};
