troops = {
    troop('F-4 THE ONE SQUADRON', _('F-4 THE ONE SQUADRON'), 'F4-The_One_Squadron.png'),
    troop('F15 KNIGHTS OF THE TWIN TAIL', _('F15 KNIGHTS OF THE TWIN TAIL'), 'F15-Knights_of_the_Twin_Tail.png'),
    troop('F15 THE 2nd F-15 SQUADRON', _('F15 THE 2nd F-15 SQUADRON'), 'F15-The_2nd_F-15_Squadron.png'),
    troop('F16 THE FIRST JET SQUADRON', _('F16 THE FIRST JET SQUADRON'), 'F16-The_First_Jet_Squadron.png'),
    troop('F16 THE VALLEY SQUADRON', _('F16 THE VALLEY SQUADRON'), 'F16-The_Valley_Squadron.png'),
    troop('IDF 1st HS GUNSHIPS AH-1', _('IDF 1st HS GUNSHIPS AH-1'), 'IDF_1st_HELICOPTER_GUNSHIPS_AH-1_SQUADRON.png'),
    troop('CH-53A HS IAF AIR FORCE', _('CH-53A HS IAF AIR FORCE'), 'CH-53A_HELICOPTER_SQUADRON_AIR_FORCE_IAF.png'),
};
