troops = {
    troop('Nigerian AF', _('Nigerian Air Force'), 'Nigerian_Air_Force.png'),
	troop('NAF - 301 Flying Training School', _('NAF 301 Flying Training School'), 'Nigerian_Air_Force_301.png'),
};
