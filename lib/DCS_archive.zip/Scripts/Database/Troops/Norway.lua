troops = {
    troop('332 SQD', _('332 SQD'), '332b.png'),
    troop('332 SQDN FIGHTING FALCON', _('332 SQDN FIGHTING FALCON'), '332c.png'),
    troop('334 SQUADRON', _('334 SQUADRON'), '334b.png'),
    troop('334 SQD F-16 NORWAY', _('34 SQD F-16 NORWAY'), '334c.png'),
    troop('UN UNPROFOR BELL 412 SP', _('UN UNPROFOR BELL 412 SP'), 'UN_UNPROFOR_BELL_4_2_SP.png'),
};
