troops = {
    troop('Peruvian AF', _('Fuerza Aérea del Perú'), 'fuerza_aerea_peru.png'),
	troop('Grupo Aereo No2', _('Grupo Aereo No2'), 'FAP_GA_No2.png'),
	troop('Grupo Aereo No4', _('Grupo Aereo No4'), 'FAP_GA_No4.png'),
	troop('Grupo Aereo No6', _('Grupo Aereo No6'), 'FAP_GA_No6.png'),
	troop('Grupo Aereo No11', _('Grupo Aereo No11'), 'FAP_GA_No11.png'),
	troop('Grupo Aereo No51', _('Grupo Aereo No51'), 'FAP_GA_No51.png'),
};
