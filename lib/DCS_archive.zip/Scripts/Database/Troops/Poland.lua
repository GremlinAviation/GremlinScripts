troops = {
    troop('1 Baza Lotnictwa Transportowego ', _('1BLTr'), '3SLtr.png'),
    troop('8 Baza Lotnictwa Transportowego', _('8BLTr'), '8BLTr.png'),
	troop('23 Baza Lotnictwa Taktycznego', _('23BLT'), '23BLT.png'),
	troop('31 Baza Lotnictwa Taktycznego', _('31BLT'), '31BLT.png'),
	troop('32 Baza Lotnictwa Taktycznego', _('32BLT'), '32BLT.png'),
	troop('33 Baza Lotnictwa Transportowego', _('33BLTr'), '33BLTr.png'),
	troop('41 Baza Lotnictwa Szkolnego', _('41BLSz'), '41BLSz.png'),
	troop('42 Baza Lotnictwa Szkolnego', _('42BLSz'), '42BLSz.png'),  
};
