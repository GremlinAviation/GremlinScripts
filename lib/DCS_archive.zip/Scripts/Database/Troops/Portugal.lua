troops = {
--PORTUGUESE AIR FORCE
    troop('Section Break', _('*PORTUGUESE AIR FORCE*'), 'Portuguese_Air_Force_COA.png'),
    troop('PoAF 101 Sqn Grunts', _('PoAF 101 Sqn Grunts'), 'PoAF_101_Sqn_Grunts.png'),
	troop('PoAF 103 Sqn Snails', _('PoAF 103 Sqn Snails'), 'PoAF_103_Sqn_Snails.png'),
	troop('PoAF 201 Sqn Falcons', _('PoAF 201 Sqn Falcons'), 'PoAF_201_Sqn_Falcons.png'),
	troop('PoAF 301 Sqn Jaguars', _('PoAF 301 Sqn Jaguars'), 'PoAF_301_Sqn_Jaguars.png'),
	troop('PoAF 501 Sqn Bisons', _('PoAF 501 Sqn Bisons'), 'PoAF_501_Sqn_Bisons.png'),
	troop('PoAF 502 Sqn Elephants', _('PoAF 502 Sqn Elephants'), 'PoAF_502_Sqn_Elephants.png'),
	troop('PoAF 504 Sqn Lynxes', _('PoAF 504 Sqn Lynxes'), 'PoAF_504_Sqn_Lynxes.png'),
	troop('PoAF 552 Sqn Mosquitoes', _('PoAF 552 Sqn Mosquitoes'), 'PoAF_552_Sqn_Mosquitoes.png'),
	troop('PoAF 601 Sqn Wolves', _('PoAF 601 Sqn Wolves'), 'PoAF_601_Sqn_Wolves.png'),
	troop('PoAF 751 Sqn Cougars', _('PoAF 751 Sqn Cougars'), 'PoAF_751_Sqn_Cougars.png'),
	troop('PoAF 802 Sqn Eagles', _('PoAF 802 Sqn Eagles'), 'PoAF_802_Sqn_Eagles.png'),
};
