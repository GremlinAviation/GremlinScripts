troops = {
    troop('2 Squadron', _('2 Squadron'),'2_Squadron.png'),
	troop('15 Squadron', _('15 Squadron'),'15_Squadron.png'),
	troop('16 Squadron', _('16 Squadron'),'16_Squadron.png'),
    troop('17 Squadron', _('17 Squadron'),'17_Squadron.png'),
	troop('19 Squadron', _('19 Squadron'),'19_Squadron.png'),
    troop('21 Squadron', _('21 Squadron'),'21_Squadron.png'),
	troop('22 Squadron', _('22 Squadron'),'22_Squadron.png'),
	troop('28 Squadron', _('28 Squadron'),'28_Squadron.png'),
	troop('35 Squadron', _('35 Squadron'),'35_Squadron.png'),
	troop('44 Squadron', _('44 Squadron'),'44_Squadron.png'),
	troop('60 Squadron', _('60 Squadron'),'60_Squadron.png'),
	troop('85 Squadron', _('85 Squadron'),'85_Squadron.png'),
	troop('87 Squadron', _('87 Squadron'),'87_Squadron.png'),
	troop('107 Squadron', _('107 Squadron'),'107_Squadron.png'),
	troop('Silver Falcons', _('Silver Falcons'),'Silver_Falcons.png')

};  

