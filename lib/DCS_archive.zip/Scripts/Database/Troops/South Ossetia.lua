troops = {
    troop('South Ossetia Military Forces', _('South Ossetia Military Forces'), 'MilitaryForces.png'),    
};
