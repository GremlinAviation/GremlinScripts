troops = {
    troop('306 SQN', _('306 SQN'), '306sq.png'),
    troop('311 SQN', _('311 SQN'), '311sq.png'),
    troop('312 SQN', _('312 SQN'), '312sq.png'),
    troop('313 SQN', _('313 SQN'), '313sq.png'),
    troop('315 SQN', _('315 SQN'), '315sq.png'),
    troop('332 SQN', _('322 SQN'), '332sq.png'),
    troop('333 SQN', _('333 SQN'), '333sq.png'),
    troop('298 Squadron Master', _('298 Squadron Master'), '298_Squadron_Master.png'),
    troop('298 Soesterberg Squadron', _('298 Soesterberg Squadron'), '298sqn_Soesterberg_Netherlands.png'),
    troop('Royal Nederland Air Force(RNAF)Master', _('Royal Nederland Air Force(RNAF)Master'), 'Royal_Nederland_Air_Force(RNAF)Master.png'),
};
