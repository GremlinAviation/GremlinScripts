troops = {
    troop('111 FILO F-4E', _('111 FILO F-4E'), '111-Filo-Panter.png'),
    troop('151 NCI FILO TUNS', _('151 NCI FILO TUNS'), '151-Filo-Tuns.png'),
    troop('161 NCI FILO KOMUTANLICI 1943', _('161 NCI FILO KOMUTANLICI 1943'), '161-Filo-Yarasa.png'),
    troop('191 FILO KOBRA', _('191 FILO KOBRA'), '191-Filo-Kobra.png'),
    troop('192 FILO KAPLAN', _('192 FILO KAPLAN'), '192-Filo-Kaplan.png'),
    troop('202 FILO SARK', _('202 FILO SARK'), '202-Filo-Sark.png'),
    troop('Helicopter Attack Batallion', _('Helicopter Attack Batallion'), 'Helicopter_Attack_Batallion.png'),
    troop('H-1 HELICOPTER BATTALION', _('H-1 HELICOPTER BATTALION'), 'UH-1_HELICOPTER_BATTALION.png'),
};
