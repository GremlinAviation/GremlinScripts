troops = {
    troop('11 SQN ROYAL AIR FORCE', _('11 SQN ROYAL AIR FORCE'), '11sq.png'),
    troop('13 SQN ROYAL AIR FORCE', _('13 SQN ROYAL AIR FORCE'), '13sq.png'),
    troop('111 SQN ROYAL AIR FORCE', _('111 SQN ROYAL AIR FORCE'), '111sq.png'),
    troop('DEFENSE HELICOPTER FLYING SCHOOL', _('DEFENSE HELICOPTER FLYING SCHOOL'), 'DEFENSE_HELICOPTER_FLYING_SCHOOL.png'),
    troop('RAF 7th HS', _('RAF 7th SH'), 'RAF_7th_Squadron_helicopter.png'),
};
