templates =
{
	{name = _("1990+"), light = "airdefence_modern_light.lua", heavy = "airdefence_modern_heavy.lua", 	yearStart = 1990},
	{name = _("1980s"), light = "airdefence_80_light.lua", heavy = "airdefence_80_heavy.lua", 	yearStart = 1980, yearEnd = 1990},
	{name = _("1960s"), light = "airdefence_60_light.lua", heavy = "airdefence_60_heavy.lua", 	yearStart = 1960, yearEnd = 1970},
	{name = _("1950s"), light = "airdefence_50_light.lua", heavy = "airdefence_50_heavy.lua", 	yearStart = 1950, yearEnd = 1960},
}
