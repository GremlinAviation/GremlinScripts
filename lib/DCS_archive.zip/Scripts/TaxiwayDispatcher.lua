dispatcher = {
	newDispatcher = false,
	saveDispatchFile = false,
}
TaxiwayWidthDimensions = false