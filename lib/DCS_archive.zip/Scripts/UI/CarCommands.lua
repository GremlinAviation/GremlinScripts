function printCurSquare()
	local x,z = curSquare()
	console.out(x..", "..z)
end