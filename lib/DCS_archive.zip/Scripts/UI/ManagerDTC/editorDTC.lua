local base = _G

module('editorDTC')

local require = base.require
local pairs = base.pairs
local tostring = base.tostring
local table = base.table
local print = base.print

local DialogLoader		= require('DialogLoader')
local Window 			= require('Window')
local ScrollPane		= require('ScrollPane')
local Static			= require('Static')
local CheckBox			= require('CheckBox')
local Button			= require('Button')
local EditBox			= require('EditBox')
local U					= require('me_utilities')
local Mission			= require('me_mission')
local panel_aircraft	= require('me_aircraft')
local me_db_api			= require('me_db_api')
local Gui				= require('dxgui')

local i18n = require('i18n')

i18n.setup(_M)


cdata = {
    editorDTC = _('EDITOR DTC'),

}

local scheme
local schemeFile
local DTC_data = {}
local panels = {}
panels['main'] = {}

local unitType = nil
local descriptorByUnitType = {}


function create()
	w, h = Gui.GetWindowSize()
	
	window = DialogLoader.spawnDialogFromFile('Scripts/UI/ManagerDTC/editorDTC.dlg', cdata)
	
	pBox 		= window.pBox
	pNoVisible 	= window.pNoVisible
	
	window:setBounds(w - 400, 50, 400,  h-100)
	pBox:setBounds(0, 0, 400, h-100)
	
	windowSkin 		= window:getSkin()
	BoxSkin 		= pBox:getSkin()
	wideButtonSkin	= pNoVisible.bWideButton:getSkin()
	staticSkin		= pNoVisible.sStatic:getSkin()
	
	schemeFile = loadScheme("CoreMods\\aircraft\\F-16C\\DTC\\DTC.lua") --TEST
end

function show(b)
	if window == nil then
		create()
	end
	
	if b then
		update()
	end
	
	window:setVisible(b)
end

function update()
	pBox:clear()
	panels['main'] = {}
	panels['main'].offsetY = 50
	panels['main'].panel = window
	panels['main'].pBox = pBox
	
	if schemeFile == nil then
		return
	end
	
	DTC_data = schemeFile.defaultData
	scheme = schemeFile.scheme
	
	if scheme then
		for k,v in base.ipairs(scheme) do
			if v.panel ~= nil then
				createElement(pBox, v, panels[v.panel].offsetY)				
				panels[v.panel].offsetY = panels[v.panel].offsetY + 25
			end
			
			if v.panel == nil and v.control == 'pagePanel' then
				panels[v.id] = {}
				panels[v.id].offsetY = 0
				createPagePanel(v, panels[v.id])
			end
		end
	end
	
end

function onAction(a_actions)
	for k,action in base.ipairs(a_actions) do
		if action.fun == "show" then
			panels[action.panel].panel:setVisible(true)
		end
		
		if action.fun == "hide" then
			panels[action.panel].panel:setVisible(false)
		end
	end
end

function createElement(a_pBox, a_elem, a_offsetY)
	if a_elem.control == 'WideButton' then
		local tmpBtn = Button.new(a_elem.text)
		tmpBtn:setBounds(20, a_offsetY, 360, 20)
		tmpBtn:setSkin(wideButtonSkin)
		a_pBox:insertWidget(tmpBtn)	
		tmpBtn.onChange = function(self)
			onAction(a_elem.onChange())
		end	
	end
	
	if a_elem.control == 'Static' then
		local tmpWid = Static.new(a_elem.text)
		tmpWid:setBounds(20, a_offsetY, 360, 20)
		tmpWid:setSkin(staticSkin)
		a_pBox:insertWidget(tmpWid)	

	end
end

function createPagePanel(a_elem, a_panel)
	local tmpWin = Window.new(w - 800, 50, 400, h-100)
	tmpWin:setText(a_elem.header)
	tmpWin:setSkin(windowSkin)
	tmpWin:setVisible(false)
	a_panel.panel = tmpWin
	
	local tmpBox = ScrollPane.new()
	tmpBox:setBounds(w - 800, 50, 400, h-100)
	tmpBox:setSkin(BoxSkin)
	tmpWin:insertWidget(tmpBox)
	a_panel.pBox = tmpBox
end

function isVisible()
	if window then
		return window:getVisible()
	end
	return false
end

function loadScheme(filename)   	
    local f,err = base.loadfile(filename)
    if not f then
        base.print("ERROR: loadScheme() file not found!", err)
        return { }
    end
    local env = {_ = function(p) return p end, print = base.print} -- ;
    base.setfenv(f, env)
	local ok, res = base.pcall(f)
	if not ok then
		base.print('ERROR: loadScheme() failed to pcall "'..filename..'": '..res)
	end
    env._ = nil;
	base.print("--env-",env.version)
    return env
end

---------------------
function setData(a_unitType)
	unitType = a_unitType
	
	if unitType then
		local unitTypeDesc = DB.unit_by_type[unitType]
		if descriptorByUnitType[unitType] == nil then
			descriptorByUnitType[unitType] = {}	
		end
		
		if unitTypeDesc.DTC.IDM and descriptorByUnitType[unitType].IDM == nil then
			descriptorByUnitType[unitType].IDM = loadDescriptor(unitTypeDesc.DTC.IDM) 			
		end
		
		if unitTypeDesc.DTC.Link16 and descriptorByUnitType[unitType].Link16 == nil  then
			descriptorByUnitType[unitType].Link16 = loadDescriptor(unitTypeDesc.DTC.Link16) 			
		end
		
		if unitTypeDesc.DTC.Link4 and descriptorByUnitType[unitType].Link4 == nil  then
			descriptorByUnitType[unitType].Link4 = loadDescriptor(unitTypeDesc.DTC.Link4) 			
		end
		
		if unitTypeDesc.DTC.SADL and descriptorByUnitType[unitType].SADL == nil  then
			descriptorByUnitType[unitType].SADL = loadDescriptor(unitTypeDesc.DTC.SADL)					
		end
	end	
end

function loadDescriptor(filename)   	
    local f,err = base.loadfile(filename)
    if not f then
        base.print("ERROR: loadDescriptor() file not found!", err)
        return { }
    end
    local env = {	_ = _, 
					print = base.print,
					table = base.table,
					pairs = base.pairs,
					type  = base.type,
					tostring = base.tostring,
					string = base.string,
					tonumber = base.tonumber,
					tostring = base.tostring,
					traverseTable					= base.U.traverseTable,
					recursiveCopyTable 				= base.U.recursiveCopyTable,
					onAction 						= onAction,

				} 
    base.setfenv(f, env)
	local ok, res = base.pcall(f)
	if not ok then
		base.print('ERROR: loadDescriptor() failed to pcall "'..filename..'": '..res)
	end
    env._ = nil

    return env
end