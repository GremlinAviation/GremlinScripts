local base = _G

module('managerDTC')

local require = base.require
local pairs = base.pairs
local tostring = base.tostring
local table = base.table
local print = base.print

local DialogLoader		= require('DialogLoader')
local Static			= require('Static')
local CheckBox			= require('CheckBox')
local U					= require('me_utilities')
local EditBox			= require('EditBox')
local Mission			= require('me_mission')
local panel_aircraft	= require('me_aircraft')
local me_db_api			= require('me_db_api')
local editorDTC			= require('editorDTC')

local i18n = require('i18n')

i18n.setup(_M)


cdata = {
    managerDTC 	= _('MANAGER DTC'),
	Create		= _('Create'),
	Type		= _('Type'),
	DTC			= _('DTC'),
}


function create()
	window = DialogLoader.spawnDialogFromFile('Scripts/UI/ManagerDTC/managerDTC.dlg', cdata)
	
	window:setPosition(100,100)
	
	bCreate = window.bCreate
	
	bCreate.onChange = onChange_bCreate
end

function show(b)
	if window == nil then
		create()
	end
	
	window:setVisible(b)
end

function update()

end

function isVisible()
	if window then
		return window:getVisible()
	end
	return false
end

function onChange_bCreate()
	editorDTC.show(true)
	show(false)
end
