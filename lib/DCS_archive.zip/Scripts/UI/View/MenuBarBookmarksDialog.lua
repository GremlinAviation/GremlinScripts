-- Toolbar for the F11 view and for the RCtrl-F2 view
local DialogLoader		= require('DialogLoader')
local gettext			= require('i_18n')
local dxgui				= require('dxgui')
local SkinUtils			= require('SkinUtils')
local Skin              = require('Skin')
local Menu          	= require("Menu")
local MenuItem      	= require("MenuItem")
local MenuSubItem   	= require("MenuSubItem")
local MenuSeparatorItem = require("MenuSeparatorItem")
local MenuRadioItem 	= require("MenuRadioItem")
local MenuCheckItem 	= require("MenuCheckItem")
local Button			= require("Button")
local Terrain           = require('terrain')
local i18n 				= require('i18n')

local function _(text) 
	return gettext.dtranslate('simulator', text) 
end

-- Predefined bookmarks menu item really controls current airfield camera positions
-- for the F11 view in the handler MenuBarBookmarksDialog::onPredefinedBookmarksMenu(). 
local localization = {
	predefined_bookmarks	= _('Predefined bookmarks'),
	current_positions		= _('Current positions'),
	user_bookmarks 			= _('User Bookmarks'),
	editor    				= _('Editor'),
	clipboard				= _('Clipboard'),
	camera_mode				= _('Camera mode'),
	frontal					= _('Frontal'),
	horizontal				= _('Horizontal'),
	vertical				= _('Vertical'),
	look_down				= _('Look down'),
	world_axes				= _('World axes'),
	camera_to_clipboard 	= _('Camera to clipboard'),
	clipboard_to_camera 	= _('Clipboard to camera'),
	by_default				= _('By default (RCtrl-Numpad5)'),
	terrain_position		= _('Terrain position'),
	visible_cameras			= _('Visible'),
}

local window_
local menuBar_
local menuPredefinedBookmarks_
local menuUserBookmarks_
local menuClipboard_
local menuItemCameraMode_
local menuCameraMode_
local radioFrontal_
local radioHorizontal_
local radioVertical_
local lookDownItem_
local worldAxesItem_
local editorMenuItem_
--local button_close_
local visibleCamerasMenuItem_
	
local function setPredefinedBookmarkItems(useAirfields)
-- set PredefinedBookmarks somewhere in the Lua state 
	menuPredefinedBookmarks_:clear()	
	if PredefinedBookmarks ~= nil then
		for i = 1, table.getn(PredefinedBookmarks) do
			local bookmarkInfo = PredefinedBookmarks[i]
			local name = bookmarkInfo.name	           
			local menuItem = MenuItem.new(name)
			menuItem.id = i - 1
			menuPredefinedBookmarks_:insertItem(menuItem)
		end	
	end
	if useAirfields then
		local menuItem = MenuSeparatorItem.new()
		menuPredefinedBookmarks_:insertItem(menuItem)
		menuItem = MenuItem.new(localization.by_default)
		menuItem.id = -2	-- by default ID	
		menuPredefinedBookmarks_:insertItem(menuItem)
		
		menuItem = MenuSeparatorItem.new()
		menuPredefinedBookmarks_:insertItem(menuItem)
		menuItem = MenuItem.new(localization.terrain_position)
		menuItem.id = -1	-- terrain position ID	
		menuPredefinedBookmarks_:insertItem(menuItem)
	end
end

local function setAirdromeBookmarks()
-- PredefinedBookmarks created here (names only)

	PredefinedBookmarks = {}
	for airdromeNumber, airdromeInfo in pairs(Terrain.GetTerrainConfig('Airdromes')) do
        local locale = i18n.getLocale()		
        local name	           
        if airdromeInfo.display_name then
            name = _(airdromeInfo.display_name) 
        else
            name = airdromeInfo.names[locale] or airdromeInfo.names['en']
        end
		local bookmarkInfo = {name = name} 		
		table.insert(PredefinedBookmarks, bookmarkInfo)
	end
	--print("setAirdromeBookmarks: PredefinedBookmarks size = "..table.getn(PredefinedBookmarks)) 
end

local function updateUserBookmarkItems()
--	print('updateUserBookmarkItems')
	local items_count = menuUserBookmarks_:getItemCount()
--	print(string.format('updateUserBookmarkItems: items_count = %d', items_count))
	-- Bookmark items start from 3. 0,1,2 stand for other items.   
	for i = 3, items_count - 1 do
--		print(string.format('getItem(%d)', 3))
		local item = menuUserBookmarks_:getItem(3)
--		print(string.format('removeItem(%s, id = %d)', item:getText(), item.id))
		menuUserBookmarks_:removeItem(item)
	end
-- set UserBookmarks somewhere in the Lua state
	local bookmarks_count = 0
	if UserBookmarks ~= nil then
		bookmarks_count = table.getn(UserBookmarks)
--		print(string.format('updateUserBookmarkItems: %d bookmarks', bookmarks_count))
		for i = 1, bookmarks_count do
			local bookmarkInfo = UserBookmarks[i]
			local name = bookmarkInfo.name
			menuItem = MenuItem.new(name)
			menuItem.id = i - 1 + 3
--			print(string.format('insertItem(%s, id = %d)', name, menuItem.id))
			menuUserBookmarks_:insertItem(menuItem)
		end
	end
	items_count = menuUserBookmarks_:getItemCount()
--	print(string.format('updateUserBookmarkItems: items_count = %d', items_count))
end

local function setEditorCheckBox(state)
	editorMenuItem_:setState(state)
end

local function setVisibleCamerasCheckBox(state)
	visibleCamerasMenuItem_:setState(state)
end

local function setCameraModeRadio(id)
	if menuCameraMode_ then
		menuCameraMode_:setRadio(id)
	end
end 

local function setClipboardItems(useAirfields)
	local id = 0
    local menuItem = MenuItem.new(localization.camera_to_clipboard)
	menuItem.id = id
	menuClipboard_:insertItem(menuItem)
	if useAirfields then		
		id = id + 1
		menuItem = MenuItem.new(localization.clipboard_to_camera)
		menuItem.id = id
		menuClipboard_:insertItem(menuItem)
	end
end

local function create(useAirfields, useCameraMode)		
	local screenWidth, screenHeight = dxgui.GetWindowSize()
--	print('screen:', screenWidth, screenHeight)
	if useAirfields then
		localization.predefined_bookmarks = localization.current_positions
	end
	window_ = DialogLoader.spawnDialogFromFile('./Scripts/UI/View/MenuBarBookmarksDialog.dlg', localization)
	local w, h = window_:getSize()
--	print('dialog:', w, h)
	window_:setBounds(0, 0, screenWidth, h)	
--	window_:setSkin(SkinUtils.setWindowBkgColor(window_:getSkin(), 0x00000080))
	menuBar_ = window_.menuBarTop
	--button_close_ = window_.button_close
	menuPredefinedBookmarks_ = menuBar_.menuBarItemPredefinedBookmarks.menu
	menuUserBookmarks_ = menuBar_.menuBarItemUserBookmarks.menu
	menuClipboard_ = menuBar_.menuBarItemClipboard.menu
	menuItemCameraMode_ = menuBar_.menuBarItemCameraMode
	
	editorMenuItem_ = menuUserBookmarks_.menuCheckItemEditor
	editorMenuItem_.id = 0
	visibleCamerasMenuItem_	= menuUserBookmarks_.menuCheckItemVisible
	visibleCamerasMenuItem_.id = 1
	menuUserBookmarks_.menuSeparatorItemSeparator.id = 2
		
	setClipboardItems(useAirfields)
	
	if not useCameraMode then
		menuBar_:removeItem(menuItemCameraMode_)
		menuItemCameraMode_ = nil
		menuCameraMode_ = nil
	else	
		menuCameraMode_ = menuItemCameraMode_.menu
		radioFrontal_ = menuCameraMode_.menuRadioItemFrontal
		radioFrontal_.id = 0
		radioHorizontal_ = menuCameraMode_.menuRadioItemHorizontal
		radioHorizontal_.id = 1
		radioVertical_ = menuCameraMode_.menuRadioItemVertical
		radioVertical_.id = 2
		radioFrontal_:setState(true)
		
		lookDownItem_ = menuCameraMode_.menuLookDownItem
		lookDownItem_.id = 4
		worldAxesItem_ = menuCameraMode_.menuWorldAxesItem
		worldAxesItem_.id = 5
		
		function menuCameraMode_:onChange()
			local item = self:getSelectedItem()
--			print("menuCameraMode_:onChange()-> id = "..item.id..", text = "..item:getText())
			if item.id < 3 then
				MenuBarBookmarksDialog_onCameraModeRadio(item.id)
			elseif item.id == 4 then
				MenuBarBookmarksDialog_onCameraLookDown()
			elseif item.id == 5 then
				MenuBarBookmarksDialog_onCameraWorldAxes()
			end
		end
		
		function menuCameraMode_:setRadio(id)
			if id == 0 then
				radioFrontal_:setState(true)
			else 
				if id == 1 then
					radioHorizontal_:setState(true)
				else 
					if id == 2 then
						radioVertical_:setState(true)
					end
				end
			end
		end
	end	
	
	function menuPredefinedBookmarks_:onChange()
		local item = self:getSelectedItem()
--		print("menuPredefinedBookmarks_:onChange()-> id = "..item.id..", text = "..item:getText())
		MenuBarBookmarksDialog_onPredefinedBookmarksMenu(item.id, item:getText())
	end
	
	function menuUserBookmarks_:onChange()
		local item = self:getSelectedItem()
--		print("menuUserBookmarks_:onChange()-> id = "..item.id..", text = "..item:getText())
		if item.id == 0 then
			local state = item:getState()
--			print('state =', state)
			MenuBarBookmarksDialog_onEditorCheckBox(state)
		elseif item.id == 1 then
			local state = item:getState()
			MenuBarBookmarksDialog_onVisibleCamerasCheckBox(state)
		elseif item.id == 2 then

		else
			MenuBarBookmarksDialog_onUserBookmarksMenu(item.id - 3, item:getText())
		end
	end
	
	function menuClipboard_:onChange()
		local item = self:getSelectedItem()
--		print("menuClipboard_:onChange()-> id = "..item.id..", text = "..item:getText())
		MenuBarBookmarksDialog_onClipboardMenu(item.id, item:getText())
	end
--[[	
	function button_close_:onChange()
		onButtonClose()
	end
--]]
	if useAirfields then
		setAirdromeBookmarks()	-- C++	
		setPredefinedBookmarkItems(useAirfields)
	end

-- 	setPredefinedBookmarkItems(useAirfields) -- call from C++ if useAirfields == 0 	
--	updateUserBookmarkItems()	-- called from C++
	
end


local function kill()
	window_:kill()
	window_ = nil
end

local function show()
	window_:setVisible(true)
end

local function hide()
	window_:setVisible(false)
end

local function setVisible(state)
	window_:setVisible(state)
end

local function isVisible()
	return window_:getVisible()
end

local function getWindow()
	return window_.widget
end

return {
	create								= create,
	kill								= kill,
	show								= show,
	hide								= hide,
	setVisible							= setVisible,
	getWindow							= getWindow,
	isVisible							= isVisible,
		
	setPredefinedBookmarkItems			= setPredefinedBookmarkItems,
	setAirdromeItems					= setAirdromeItems,
	updateUserBookmarkItems				= updateUserBookmarkItems,
	setEditorCheckBox					= setEditorCheckBox,
	setCameraModeRadio					= setCameraModeRadio,
	setVisibleCamerasCheckBox			= setVisibleCamerasCheckBox,
}
