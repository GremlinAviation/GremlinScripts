local DialogLoader		= require('DialogLoader')
local gettext			= require('i_18n')
local dxgui				= require('dxgui')
local Window            = require('Window')
local Widget			= require('Widget')
local SkinUtils         = require('SkinUtils')
local Skin              = require('Skin')

local function _(text) 
	return gettext.dtranslate('simulator', text) 
end

local localization = {
	newBookmark	= _('New Bookmark'),
	enterUniqueBookmarkName = _('Enter unique bookmark name'),
	ok    		= _('OK'),
	cancel		= _('Cancel'),
}

local window_
local editBoxName_
local buttonOK_
local buttonCancel_

local function create()	
--	print('NewBookmarkDialog.create()')
	window_ = DialogLoader.spawnDialogFromFile('./Scripts/UI/View/NewBookmarkDialog.dlg', localization)
	window_:setText(localization.newBookmark)
	window_:setPosition(600, 50)
	window_:setSkin(SkinUtils.setWindowBkgColor(window_:getSkin(), 0x000000A0))
	editBoxName_ = window_.editBoxName
	editBoxName_:setText('')
	buttonOK_ = window_.panelButtons.buttonOK
	buttonOK_:setText(localization.ok)
	buttonCancel_ = window_.panelButtons.buttonCancel
	buttonCancel_:setText(localization.cancel)
	
	function buttonOK_:onChange()
--		print('buttonOK_:onChange()')
		local name = editBoxName_:getText()
--		print('name = ', name)
		NewBookmarkDialog_onButtonOK(name)	-- C++ callback
		editBoxName_:setText('')
		window_:setVisible(false)
	end
	
	function buttonCancel_:onChange()
--		print('buttonJump_:onChange()')
		editBoxName_:setText('')
		window_:setVisible(false)
	end
	
end

local function kill()
	window_:kill()
	window_ = nil
end

local function show()
	editBoxName_:setText('')
	window_:setVisible(true)
end

local function hide()
	window_:setVisible(false)
end

local function getWindow()
	return window_.widget
end

return {
	create								= create,
	kill								= kill,
	show								= show,
	hide								= hide,
	getWindow							= getWindow,
}
