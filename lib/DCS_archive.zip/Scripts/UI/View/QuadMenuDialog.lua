local base = _G

module('QuadMenuDialog')

mtab = {__index = _M}	
					
local require	= base.require
local pairs		= base.pairs
local table = base.table
local string = base.string
local ipairs	= base.ipairs
local print		= base.print
local math		= base.math
local type		= base.type
local tostring	= base.tostring
local loadfile	= base.loadfile
local setmetatable = base.setmetatable

local Window = require('Window')
local loader = require('DialogLoader')
local i18n = require('i18n')
local Skin = require('Skin')
local Gui = require("dxgui")
local Static = require('Static')
local UICommon = require('UICommon')

i18n.setup(_M)

local cdata = {
-- not localized
}

function create()
	print('QuadMenuDialog.construct()')
    window_ = loader.spawnDialogFromFile("Scripts/UI/View/QuadMenuDialog.dlg")
	if window_ == nil or window_.widget == nil then
		print('Error loading QuadMenuDialog.dlg')
		return
	end
	window_:setPosition(0, 0)
		staticCenter = window_.staticCenter
			staticArrowUp = window_.staticArrowUp
			staticUp = window_.staticUp
				staticArrowUpUp = window_.staticArrowUpUp
				staticUpUp = window_.staticUpUp
				staticArrowUpLeft = window_.staticArrowUpLeft
				staticUpLeft = window_.staticUpLeft
				staticArrowUpRight = window_.staticArrowUpRight
				staticUpRight = window_.staticUpRight
			staticDown = window_.staticDown
			staticArrowDown = window_.staticArrowDown
				staticArrowDownDown = window_.staticArrowDownDown
				staticDownDown = window_.staticDownDown
				staticArrowDownLeft = window_.staticArrowDownLeft
				staticDownLeft = window_.staticDownLeft
				staticArrowDownRight = window_.staticArrowDownRight
				staticDownRight = window_.staticDownRight
			staticArrowLeft = window_.staticArrowLeft
			staticLeft = window_.staticLeft
				staticArrowLeftUp = window_.staticArrowLeftUp
				staticLeftUp = window_.staticLeftUp
				staticArrowLeftLeft = window_.staticArrowLeftLeft
				staticLeftLeft = window_.staticLeftLeft
				staticArrowLeftDown = window_.staticArrowLeftDown
				staticLeftDown = window_.staticLeftDown
			staticArrowRight = window_.staticArrowRight
			staticRight = window_.staticRight
				staticArrowRightUp = window_.staticArrowRightUp
				staticRightUp = window_.staticRightUp
				staticArrowRightRight = window_.staticArrowRightRight
				staticRightRight = window_.staticRightRight
				staticArrowRightDown = window_.staticArrowRightDown
				staticRightDown = window_.staticRightDown
					
	print('QuadMenuDialog created')
end

function init(root_node)
	root = root_node
	current = root
	update()
end

function destroy()
	if window_ == nil then return end

	window_:kill()
	window_ = nil
end

function show()
	if window_ == nil then return end
	update()
	window_:setVisible(true)
end

function hide()
	if window_ == nil then return end
	window_:setVisible(false)
end

function isVisible()
	if window_ == nil then 
		return false 
	end
	return window_:getVisible()
end
 
function onUp()
	if window_ == nil then 
		return 
	end
	if current ~= nil then
		print(string.format('QuadMenuDialog.onUp: current.text = %s', current.text))
		if current.up ~= nil then
			current = current.up
			print(string.format('QuadMenuDialog: changed to current.text = %s', current.text))
			if current.type == 'leaf' then
				--print(string.format('QuadMenuDialog: leaf current.text = %s', current.text))
				if current.callback then
					current.callback(current)
				end
				current = root
				update()
				print(string.format('QuadMenuDialog: changed to root current.text = %s', current.text))
				--hide()
			else
				update()
			end
		end
	end
end

function onDown()
	if window_ == nil then 
		return 
	end
	if current ~= nil then
		print(string.format('QuadMenuDialog.onDown: current.text = %s', current.text))
		if current.down ~= nil then
			current = current.down
			print(string.format('QuadMenuDialog: changed to current.text = %s', current.text))
			if current.type == 'leaf' then
				--print(string.format('QuadMenuDialog: leaf current.text = %s', current.text))
				if current.callback then
					current.callback(current)
				end
				current = root
				update()
				print(string.format('QuadMenuDialog: changed to root current.text = %s', current.text))
				--hide()
			else
				update()
			end
		end
	end
end

function onLeft()
	if window_ == nil then 
		return 
	end
	if current ~= nil then
		print(string.format('QuadMenuDialog.onLeft: current.text = %s', current.text))
		if current.left ~= nil then
			current = current.left
			print(string.format('QuadMenuDialog: changed to current.text = %s', current.text))
			if current.type == 'leaf' then
				--print(string.format('QuadMenuDialog: leaf current.text = %s', current.text))
				if current.callback then
					current.callback(current)
				end
				current = root
				update()
				print(string.format('QuadMenuDialog: changed to root current.text = %s', current.text))
				--hide()
			else
				update()
			end
		end
	end
end

function onRight()
	if window_ == nil then 
		return 
	end
	if current ~= nil then
		print(string.format('QuadMenuDialog.onRight: current.text = %s', current.text))
		if current.right ~= nil then
			current = current.right
			print(string.format('QuadMenuDialog: changed to current.text = %s', current.text))
			if current.type == 'leaf' then
				--print(string.format('QuadMenuDialog: leaf current.text = %s', current.text))
				if current.callback then
					current.callback(current)
				end
				current = root
				update()
				print(string.format('QuadMenuDialog: changed to root current.text = %s', current.text))
				--hide()
			else
				update()
			end
		end
	end
end

function onCenter()
	if window_ == nil then 
		return 
	end
	current = root
	print(string.format('QuadMenuDialog.onCenter: root current.text = %s', current.text))
	update()
end

local function clear_all()	
	staticCenter:setVisible(false)
		staticArrowUp:setVisible(false)
		staticUp:setVisible(false)
			staticArrowUpUp:setVisible(false)
			staticUpUp:setVisible(false)
			staticArrowUpLeft:setVisible(false)
			staticUpLeft:setVisible(false)
			staticArrowUpRight:setVisible(false)
			staticUpRight:setVisible(false)
		staticDown:setVisible(false)
		staticArrowDown:setVisible(false)
			staticArrowDownDown:setVisible(false)
			staticDownDown:setVisible(false)
			staticArrowDownLeft:setVisible(false)
			staticDownLeft:setVisible(false)
			staticArrowDownRight:setVisible(false)
			staticDownRight:setVisible(false)
		staticArrowLeft:setVisible(false)
		staticLeft:setVisible(false)
			staticArrowLeftUp:setVisible(false)
			staticLeftUp:setVisible(false)
			staticArrowLeftLeft:setVisible(false)
			staticLeftLeft:setVisible(false)
			staticArrowLeftDown:setVisible(false)
			staticLeftDown:setVisible(false)
		staticArrowRight:setVisible(false)
		staticRight:setVisible(false)
			staticArrowRightUp:setVisible(false)
			staticRightUp:setVisible(false)
			staticArrowRightRight:setVisible(false)
			staticRightRight:setVisible(false)
			staticArrowRightDown:setVisible(false)
			staticRightDown:setVisible(false)
				
end

function update()
	if window_ == nil then 
		return 
	end
	clear_all()
	if current ~= nil then
		staticCenter:setText(current.text)
		staticCenter:setVisible(true)
		
		staticUp:setVisible(current.up ~= nil)
		staticArrowUp:setVisible(current.up ~= nil)
		if current.up then
			staticUp:setText(current.up.text)
			staticUpUp:setVisible(current.up.up ~= nil)
			staticArrowUpUp:setVisible(current.up.up ~= nil)
			if current.up.up then
				staticUpUp:setText(current.up.up.text)
			end
			staticUpLeft:setVisible(current.up.left ~= nil)
			staticArrowUpLeft:setVisible(current.up.left ~= nil)
			if current.up.left then
				staticUpLeft:setText(current.up.left.text)
			end
			staticUpRight:setVisible(current.up.right ~= nil)
			staticArrowUpRight:setVisible(current.up.right ~= nil)
			if current.up.right then
				staticUpRight:setText(current.up.right.text)
			end
		end
				
		staticDown:setVisible(current.down ~= nil)
		staticArrowDown:setVisible(current.down ~= nil)
		if current.down then
			staticDown:setText(current.down.text)
			staticDownDown:setVisible(current.down.down ~= nil)
			staticArrowDownDown:setVisible(current.down.down ~= nil)
			if current.down.down then
				staticDownDown:setText(current.down.down.text)
			end
			staticDownLeft:setVisible(current.down.left ~= nil)
			staticArrowDownLeft:setVisible(current.down.left ~= nil)
			if current.down.left then
				staticDownLeft:setText(current.down.left.text)
			end
			staticDownRight:setVisible(current.down.right ~= nil)
			staticArrowDownRight:setVisible(current.down.right ~= nil)
			if current.down.right then
				staticDownRight:setText(current.down.right.text)
			end
		end
		
		staticLeft:setVisible(current.left ~= nil)
		staticArrowLeft:setVisible(current.left ~= nil)
		if current.left then
			staticLeft:setText(current.left.text)
			staticLeftDown:setVisible(current.left.down ~= nil)
			staticArrowLeftDown:setVisible(current.left.down ~= nil)
			if current.left.down then
				staticLeftDown:setText(current.left.down.text)
			end
			staticLeftLeft:setVisible(current.left.left ~= nil)
			staticArrowLeftLeft:setVisible(current.left.left ~= nil)
			if current.left.left then
				staticLeftLeft:setText(current.left.left.text)
			end
			staticLeftUp:setVisible(current.left.up ~= nil)
			staticArrowLeftUp:setVisible(current.left.up ~= nil)
			if current.left.up then
				staticLeftUp:setText(current.left.up.text)
			end
		end
		
		staticRight:setVisible(current.right ~= nil)
		staticArrowRight:setVisible(current.right ~= nil)
		if current.right then
			staticRight:setText(current.right.text)
			staticRightDown:setVisible(current.right.down ~= nil)
			staticArrowRightDown:setVisible(current.right.down ~= nil)
			if current.right.down then
				staticRightDown:setText(current.right.down.text)
			end
			staticRightRight:setVisible(current.right.right ~= nil)
			staticArrowRightRight:setVisible(current.right.right ~= nil)
			if current.right.right then
				staticRightRight:setText(current.right.right.text)
			end
			staticRightUp:setVisible(current.right.up ~= nil)
			staticArrowRightUp:setVisible(current.right.up ~= nil)
			if current.right.up then
				staticRightUp:setText(current.right.up.text)
			end
		end
	end
end
