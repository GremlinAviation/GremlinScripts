local base = _G

module('QuadMenuDialog')

mtab = {__index = _M}	

local Factory   = base.require('Factory')					
local require	= base.require
local pairs		= base.pairs
local table = base.table
local string = base.string
local ipairs	= base.ipairs
local print		= base.print
local math		= base.math
local type		= base.type
local tostring	= base.tostring
local loadfile	= base.loadfile
local setmetatable = base.setmetatable

local Window = require('Window')
local loader = require('DialogLoader')
local i18n = require('i18n')
local Skin = require('Skin')
local Gui = require("dxgui")
local Static = require('Static')
local UICommon = require('UICommon')

i18n.setup(_M)

window_ = nil

local cdata = {
-- not localized
}

function create()
	if window_ ~= nil then return end
	print('QuadMenuDialog.create()')
    window_ = loader.spawnDialogFromFile("Scripts/UI/View/QuadMenuDialog.dlg")
	if window_ == nil or window_.widget == nil then
		print('Error loading QuadMenuDialog.dlg')
	end
	window_:setPosition(30, 30)
	panelTop = window_.panelTop
		staticCenter = panelTop.staticCenter
		staticUp = panelTop.staticUp
		staticDown = panelTop.staticDown
		staticLeft = panelTop.staticLeft
		staticRight = panelTop.staticRight
		staticArrowUp = panelTop.staticArrowUp
		staticArrowDown = panelTop.staticArrowDown
		staticArrowLeft = panelTop.staticArrowLeft
		staticArrowRight = panelTop.staticArrowRight
		
	init_test();
	
	print('QuadMenuDialog created')
end

-- test data
local node1 = { type = 'node', text = 'node1', }
local node2 = { type = 'node', text = 'node2', }
local node3 = { type = 'node', text = 'node3', }
local node4 = { type = 'node', text = 'node4', }
local node5 = { type = 'node', text = 'node5', }
local node6 = { type = 'node', text = 'node6', }
local node7 = { type = 'node', text = 'node7', }
local node8 = { type = 'node', text = 'node8', }

local leaf1 = { type = 'leaf', text = 'leaf1', }
local leaf2 = { type = 'leaf', text = 'leaf2', }
local leaf3 = { type = 'leaf', text = 'leaf3', }
local leaf4 = { type = 'leaf', text = 'leaf4', }
local leaf5 = { type = 'leaf', text = 'leaf5', }
local leaf6 = { type = 'leaf', text = 'leaf6', }
local leaf7 = { type = 'leaf', text = 'leaf7', }
local leaf8 = { type = 'leaf', text = 'leaf8', }
local leaf9 = { type = 'leaf', text = 'leaf9', }
local leaf10 = { type = 'leaf', text = 'leaf10', }
local leaf11 = { type = 'leaf', text = 'leaf11', }
local leaf12 = { type = 'leaf', text = 'leaf12', }
local leaf13 = { type = 'leaf', text = 'leaf13', }
local leaf14 = { type = 'leaf', text = 'leaf14', }
local leaf15 = { type = 'leaf', text = 'leaf15', }


function init_test()	
	node1.up = node3
	node3.down = node1
	node1.down = node5
	node5.up = node1
	node1.left = node2
	node2.right = node1
	node1.right = node4
	node4.left = node1
	
	node2.up = leaf15
	leaf15.down = node2
	node2.left = leaf14
	leaf14.right = node2
	node2.down = node6
	node6.up = node2
	
	node3.up = leaf2
	leaf2.down = node3
	node3.left = leaf1
	leaf1.right = node3
	node3.right = leaf3
	leaf3.left = node3
	
	node4.up = leaf4
	leaf4.down = node4
	node4.down = leaf5
	leaf5.up = node4
	node4.right = node7
	node7.left = node4
	
	node5.down = leaf10
	leaf10.up = node5
	node5.left = leaf11
	leaf11.right = node5
	node5.right = node8
	node8.left = node5
	
	node6.down = leaf12
	leaf12.up = node6
	node6.left = leaf13
	leaf13.right = node6
	
	node7.up = leaf6
	leaf6.down = node7
	node7.right = leaf7
	leaf7.left = node7
	
	node8.down = leaf9
	leaf9.up = node8
	node8.right = leaf8
	leaf8.left = node8
	
	root = node1
	current = root
	
	update()
end

function destroy()
	if window_ == nil then return end

	window_:kill()
	window_ = nil
end

function show()
	if window_ == nil then return end
	update()
	window_:setVisible(true)
end

function hide()
	if window_ == nil then return end
	window_:setVisible(false)
end

function isVisible()
	if window_ == nil then 
		return false 
	end
	return window_:getVisible()
end
 
function onUp()
	if window_ == nil or not window_:getVisible() then 
		return 
	end
	if current ~= nil then
		print(string.format('QuadMenuDialog.onUp: current.text = %s', current.text))
		if current.up ~= nil then
			current = current.up
			print(string.format('QuadMenuDialog: changed to current.text = %s', current.text))
			if current.type == 'leaf' then
				print(string.format('QuadMenuDialog: leaf current.text = %s', current.text))
				base.onQuadMenu(current.text)
				current = root
				update()
				print(string.format('QuadMenuDialog: changed to root current.text = %s', current.text))
				hide()
			else
				update()
			end
		end
	end
end

function onDown()
	if window_ == nil or not window_:getVisible() then 
		return 
	end
	if current ~= nil then
		print(string.format('QuadMenuDialog.onDown: current.text = %s', current.text))
		if current.down ~= nil then
			current = current.down
			print(string.format('QuadMenuDialog: changed to current.text = %s', current.text))
			if current.type == 'leaf' then
				print(string.format('QuadMenuDialog: leaf current.text = %s', current.text))
				base.onQuadMenu(current.text)
				current = root
				update()
				print(string.format('QuadMenuDialog: changed to root current.text = %s', current.text))
				hide()
			else
				update()
			end
		end
	end
end

function onLeft()
	if window_ == nil or not window_:getVisible() then 
		return 
	end
	if current ~= nil then
		print(string.format('QuadMenuDialog.onLeft: current.text = %s', current.text))
		if current.left ~= nil then
			current = current.left
			print(string.format('QuadMenuDialog: changed to current.text = %s', current.text))
			if current.type == 'leaf' then
				print(string.format('QuadMenuDialog: leaf current.text = %s', current.text))
				base.onQuadMenu(current.text)
				current = root
				update()
				print(string.format('QuadMenuDialog: changed to root current.text = %s', current.text))
				hide()
			else
				update()
			end
		end
	end
end

function onRight()
	if window_ == nil or not window_:getVisible() then 
		return 
	end
	if current ~= nil then
		print(string.format('QuadMenuDialog.onRight: current.text = %s', current.text))
		if current.right ~= nil then
			current = current.right
			print(string.format('QuadMenuDialog: changed to current.text = %s', current.text))
			if current.type == 'leaf' then
				print(string.format('QuadMenuDialog: leaf current.text = %s', current.text))
				base.onQuadMenu(current.text)
				current = root
				update()
				print(string.format('QuadMenuDialog: changed to root current.text = %s', current.text))
				hide()
			else
				update()
			end
		end
	end
end

function onCenter()
	if window_ == nil or not window_:getVisible() then 
		return 
	end
	current = root
	print(string.format('QuadMenuDialog.onCenter: root current.text = %s', current.text))
	update()
end

function update()
	if window_ == nil or not window_:getVisible() then 
		return 
	end
	if current ~= nil then
		staticCenter:setText(current.text)
		staticCenter:setVisible(true)
		
		staticUp:setVisible(current.up ~= nil)
		staticArrowUp:setVisible(current.up ~= nil)
		if current.up then
			staticUp:setText(current.up.text)
		end
		
		staticDown:setVisible(current.down ~= nil)
		staticArrowDown:setVisible(current.down ~= nil)
		if current.down then
			staticDown:setText(current.down.text)
		end
		
		staticLeft:setVisible(current.left ~= nil)
		staticArrowLeft:setVisible(current.left ~= nil)
		if current.left then
			staticLeft:setText(current.left.text)
		end
		
		staticRight:setVisible(current.right ~= nil)
		staticArrowRight:setVisible(current.right ~= nil)
		if current.right then
			staticRight:setText(current.right.text)
		end
	end
end
