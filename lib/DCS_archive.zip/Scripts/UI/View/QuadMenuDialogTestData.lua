-- QuadMenuDialogTestData

-- nodes
local node1 	= 	{ type = 'node', text = 'node1', 	}
local node2 	= 	{ type = 'node', text = 'node2', 	}
local node3 	= 	{ type = 'node', text = 'node3', 	}
local node4 	= 	{ type = 'node', text = 'node4', 	}
local node5 	= 	{ type = 'node', text = 'node5', 	}
local node6 	= 	{ type = 'node', text = 'node6', 	}
local node7 	= 	{ type = 'node', text = 'node7', 	}
local node8 	= 	{ type = 'node', text = 'node8', 	}
local node9 	= 	{ type = 'node', text = 'node9', 	}
local node10 	= 	{ type = 'node', text = 'node10', 	}

-- leaf callback
local function onLeaf(node)
	print(string.format('onLeaf(%s)', node.text))
end

-- leafs
local leaf1 = { type = 'leaf', text = 'leaf1', callback = onLeaf, }
local leaf2 = { type = 'leaf', text = 'leaf2', callback = onLeaf, }
local leaf3 = { type = 'leaf', text = 'leaf3', callback = onLeaf, }
local leaf4 = { type = 'leaf', text = 'leaf4', callback = onLeaf, }
local leaf5 = { type = 'leaf', text = 'leaf5', callback = onLeaf, }
local leaf6 = { type = 'leaf', text = 'leaf6', callback = onLeaf, }
local leaf7 = { type = 'leaf', text = 'leaf7', callback = onLeaf, }
local leaf8 = { type = 'leaf', text = 'leaf8', callback = onLeaf, }
local leaf9 = { type = 'leaf', text = 'leaf9', callback = onLeaf, }
local leaf10 = { type = 'leaf', text = 'leaf10', callback = onLeaf, }
local leaf11 = { type = 'leaf', text = 'leaf11', callback = onLeaf, }
local leaf12 = { type = 'leaf', text = 'leaf12', callback = onLeaf, }
local leaf13 = { type = 'leaf', text = 'leaf13', callback = onLeaf, }
local leaf14 = { type = 'leaf', text = 'leaf14', callback = onLeaf, }
local leaf15 = { type = 'leaf', text = 'leaf15', callback = onLeaf, }
local leaf16 = { type = 'leaf', text = 'leaf16', callback = onLeaf, }
local leaf17 = { type = 'leaf', text = 'leaf17', callback = onLeaf, }
local leaf18 = { type = 'leaf', text = 'leaf18', callback = onLeaf, }
local leaf19 = { type = 'leaf', text = 'leaf19', callback = onLeaf, }
local leaf20 = { type = 'leaf', text = 'leaf20', callback = onLeaf, }

local function connect(node, up, down, left, right)
	if node then
		node.up = up
		if up then
			up.down = node
		end
		node.down = down
		if down then
			down.up = node
		end
		node.left = left
		if left then
			left.right = node
		end
		node.right = right
		if right then
			right.left = node
		end
	end
end
-- connecting nodes for test structure
--[[
                   leaf2
                     |
		     leaf1-node3-leaf3
                     |
        leaf15       |        leaf4      leaf6
		  |          |          |          |
 leaf14-node2------node1------node4------node7-leaf7
		  |          |          |          |
          |          |        leaf5        |       leaf18
		  |          |                     |         |
 leaf13-node6        |            leaf16-node9-----node10-leaf19
		  |          |                     |         |
		leaf12       |                   leaf17    leaf20
		             |
		    leaf11-node5------node8-leaf8
			         |          |
				   leaf10     leaf9
--]]
--		node	up		down	left	right
connect(node1, 	node3, 	node5, 	node2, 	node4)	
connect(node2, 	leaf15, node6, 	leaf14, node1)
connect(node3, 	leaf2, 	node1,	leaf1,	leaf3)
connect(node4,	leaf4, 	leaf5,	node1,	node7)
connect(node5,	node1,	leaf10,	leaf11,	node8)
connect(node6,	node2,	leaf12,	leaf13,	nil)
connect(node7,	leaf6,	node9,	node4,	leaf7)
connect(node8, 	nil,	leaf9,	node5,	leaf8)
connect(node9,  node7,  leaf17, leaf16, node10)
connect(node10, leaf18, leaf20, node9,  leaf19)

return node1
