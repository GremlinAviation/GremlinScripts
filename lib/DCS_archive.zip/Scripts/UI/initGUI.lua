package.path =	package.path
				.. ';./Scripts/?.lua;'
				.. './Scripts/Common/?.lua;'
				.. './Scripts/UI/?.lua;'
				.. './Scripts/UI/F10View/?.lua;'
				.. './Scripts/UI/View/?.lua;'
				.. './Scripts/DemoScenes/?.lua;'
				.. './dxgui/bind/?.lua;'
				.. './dxgui/loader/?.lua;'
				.. './dxgui/skins/skinME/?.lua;'
				.. './dxgui/skins/common/?.lua;'
				.. './MissionEditor/modules/?.lua;'
				
local dxgui	= require('dxgui')