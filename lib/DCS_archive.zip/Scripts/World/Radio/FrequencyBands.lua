-- Frequency bands
HF = 0
VHF_LOW = 1
VHF_HI = 2
UHF = 3
